<?php
return array(
	'name' => esc_html__( 'Help', 'vip-restaurant' ),
	'auto' => true,
	'config' => array(

		array(
			'name' => esc_html__( 'Help', 'vip-restaurant' ),
			'type' => 'title',
			'desc' => '',
		),

		array(
			'name' => esc_html__( 'Help', 'vip-restaurant' ),
			'type' => 'start',
			'nosave' => true,
		),
//----
		array(
			'type' => 'docs',
		),

			array(
				'type' => 'end',
			),
	),
);
