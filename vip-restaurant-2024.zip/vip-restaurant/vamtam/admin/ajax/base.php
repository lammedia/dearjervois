<?php

function vamtam_shortcode_generator() {
	$config = array(
		'title' => esc_html__( 'Shortcodes', 'vip-restaurant' ),
		'id' => 'shortcode',
	);

	$slug = $_GET['slug'];
	$allowed_shortcodes = include VAMTAM_METABOXES . 'shortcode.php';

	if ( ! in_array( $slug, $allowed_shortcodes, true ) ) {
		exit;
	}

	$shortcodes = apply_filters( 'vamtam_shortcode_' . $slug, include( VAMTAM_SCGEN . $slug .'.php' ) );
	$generator  = new VamtamShortcodesGenerator( $config, $shortcodes );

	$generator->render();
}
add_action( 'wp_ajax_vamtam-shortcode-generator', 'vamtam_shortcode_generator' );
