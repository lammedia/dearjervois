(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

(function ($, undefined) {
	'use strict';

	var hasSelectiveRefresh = 'undefined' !== typeof wp && wp.customize && wp.customize.selectiveRefresh;

	if (hasSelectiveRefresh) {
		wp.customize.selectiveRefresh.bind('partial-content-rendered', function (placement) {
			if (placement.partial.id && placement.partial.id === 'vamtam-custom-css-partial') {
				// The current Customizer Selective Refresh implementation
				// cannot replace <style> elements in Chrome
				//
				// As a workaround, create a new <style> element
				// and replace the one inserted by Selective Refresh (partial_el)
				// with the newly created element (new_el)

				var partial_el = placement.container[0];

				var new_el = document.createElement('style');

				new_el.id = 'front-all-css';
				new_el.innerHTML = partial_el.innerHTML;

				partial_el.id = '';

				partial_el.parentNode.replaceChild(new_el, partial_el);

				// enable UI
				document.body.classList.remove('customize-partial-refreshing');

				// give the browser some time to render the new CSS and trigger a resize event
				setTimeout(function () {
					requestAnimationFrame(function () {
						$(window).trigger('resize');
					});
				}, 200);
			}
		});
	}
})(jQuery);

},{}]},{},[1]);
