<?php
/**
 * Vamtam Project Format Selector
 *
 * @package vip-restaurant
 */

return array(

array(
	'name' => esc_html__( 'Project Format', 'vip-restaurant' ),
	'type' => 'separator',
),

array(
	'name' => esc_html__( 'Project Data Type', 'vip-restaurant' ),
	'desc' => wp_kses_post( __('Image - uses the featured image (default)<br />
				  Gallery - use the featured image as a title image but show additional images too<br />
				  Video/Link - uses the "portfolio data url" setting<br />
				  Document - acts like a normal post<br />
				  HTML - overrides the image with arbitrary HTML when displaying a single project.
				', 'vip-restaurant') ),
	'id'      => 'portfolio_type',
	'type'    => 'radio',
	'options' => array(
		'image'    => esc_html__( 'Image', 'vip-restaurant' ),
		'gallery'  => esc_html__( 'Gallery', 'vip-restaurant' ),
		'video'    => esc_html__( 'Video', 'vip-restaurant' ),
		'link'     => esc_html__( 'Link', 'vip-restaurant' ),
		'document' => esc_html__( 'Document', 'vip-restaurant' ),
		'html'     => esc_html__( 'HTML', 'vip-restaurant' ),
	),
	'default' => 'image',
),

array(
	'name'    => esc_html__( 'Featured Project', 'vip-restaurant' ),
	'id'      => 'featured-project',
	'type'    => 'checkbox',
	'default' => false,
),

);
