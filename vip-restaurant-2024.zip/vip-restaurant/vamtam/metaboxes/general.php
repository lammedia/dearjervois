<?php
/**
 * Vamtam Post Options
 *
 * @package vip-restaurant
 */

return array(

array(
	'name' => esc_html__( 'Layout and Styles', 'vip-restaurant' ),
	'type' => 'separator',
),

array(
	'name'    => esc_html__( 'Page Slider', 'vip-restaurant' ),
	'desc'    => esc_html__( 'In the drop down you will see the sliders that you have created. Please note that the theme uses Revolution Slider and its option panel is found in the WordPress navigation menu on the left.', 'vip-restaurant' ),
	'id'      => 'slider-category',
	'type'    => 'select',
	'default' => '',
	'prompt'  => esc_html__( 'Disabled', 'vip-restaurant' ),
	'options' => VamtamTemplates::get_all_sliders(),
),

array(
	'name'        => esc_html__( 'Show Splash Screen', 'vip-restaurant' ),
	'desc'        => esc_html__( 'This option is useful if you have video backgrounds, featured slider, galleries or other elements that may load slowly.', 'vip-restaurant' ),
	'id'          => 'show-splash-screen-local',
	'type'        => 'toggle',
	'default'     => 'default',
	'has_default' => true,
),

array(
	'name'    => esc_html__( 'Header Featured Area', 'vip-restaurant' ),
	'desc'    => esc_html__( 'The contents of this option are placed below the header slider, even if the slider is disabled. You can place plain text or HTML into it.', 'vip-restaurant' ),
	'id'      => 'page-middle-header-content',
	'type'    => 'textarea',
	'default' => '',
),

array(
	'name'    => esc_html__( 'Full Width Header Featured Area', 'vip-restaurant' ),
	'desc'    => esc_html__( 'Extend the featured area to the end of the screen. This is basicly a full screen mode.', 'vip-restaurant' ),
	'id'      => 'page-middle-header-content-fullwidth',
	'type'    => 'toggle',
	'default' => 'false',
),

array(
	'name'    => esc_html__( 'Header Featured Area Minimum Height', 'vip-restaurant' ),
	'desc'    => esc_html__( 'Please note that this option does not affect the slider height. The slider height is controled from the LayerSlider option panel.', 'vip-restaurant' ),
	'id'      => 'page-middle-header-min-height',
	'type'    => 'range',
	'default' => 0,
	'min'     => 0,
	'max'     => 1000,
	'unit'    => 'px',
),

array(
	'name'  => esc_html__( 'Featured Area / Slider Background', 'vip-restaurant' ),
	'desc'  => esc_html__( 'This option is used for the featured area and header slider.<br>If you want to use an image as a background, enabling the cover button will resize and crop the image so that it will always fit the browser window on any resolution.', 'vip-restaurant' ),
	'id'    => 'local-title-background',
	'type'  => 'background',
	'show'  => 'color,image,repeat,size',
),

array(
	'name'    => esc_html__( 'Sticky Header Behaviour', 'vip-restaurant' ),
	'id'      => 'sticky-header-type',
	'type'    => 'select',
	'default' => 'normal',
	'desc'    => esc_html__( 'Please make sure you have the sticky header enabled in theme options - layout - header.', 'vip-restaurant' ),
	'options' => array(
		'normal'    => esc_html__( 'Normal', 'vip-restaurant' ),
		'over'      => esc_html__( 'Over the page content', 'vip-restaurant' ),
		'half-over' => esc_html__( 'Bottom part over the page content', 'vip-restaurant' ),
	),
),

array(
	'name'    => esc_html__( 'Show Page Title Area', 'vip-restaurant' ),
	'desc'    => esc_html__( 'Enables the area used by the page title.', 'vip-restaurant' ),
	'id'      => 'show-page-header',
	'type'    => 'toggle',
	'default' => true,
),

array(
	'name'    => esc_html__( 'Page Title Layout', 'vip-restaurant' ),
	'id'      => 'local-page-title-layout',
	'type'    => 'select',
	'desc'    => esc_html__( 'The first row is the Title, the second row is the Description. The description can be added in the local option panel just below the editor.', 'vip-restaurant' ),
	'default' => '',
	'prompt'  => esc_html__( 'Default', 'vip-restaurant' ),
	'options' => array(
		'centered'      => esc_html__( 'Two rows, centered', 'vip-restaurant' ),
		'one-row-left'  => esc_html__( 'One row, title on the left', 'vip-restaurant' ),
		'one-row-right' => esc_html__( 'One row, title on the right', 'vip-restaurant' ),
		'left-align'    => esc_html__( 'Two rows, left-aligned', 'vip-restaurant' ),
		'right-align'   => esc_html__( 'Two rows, right-aligned', 'vip-restaurant' ),
	),
),

array(
	'name'  => esc_html__( 'Page Title Background', 'vip-restaurant' ),
	'id'    => 'local-page-title-background',
	'type'  => 'background',
	'show'  => 'color,image,repeat,size,attachment',
),

array(
	'name'    => esc_html__( 'Page Title Shadow', 'vip-restaurant' ),
	'id'      => 'has-page-title-shadow',
	'type'    => 'toggle',
	'default' => false,
),

array(
	'name'  => esc_html__( 'Page Title Color Override', 'vip-restaurant' ),
	'id'    => 'local-page-title-color',
	'type'  => 'color',
),

array(
	'name'    => esc_html__( 'Description', 'vip-restaurant' ),
	'desc'    => esc_html__( 'The text will appear next or bellow the title of the page, only if the option above is enabled.', 'vip-restaurant' ),
	'id'      => 'description',
	'type'    => 'textarea',
	'default' => '',
),

array(
	'name' => esc_html__( 'Page Background', 'vip-restaurant' ),
	'desc' => wp_kses_post( __('Please note that this option is used only in boxed layout mode.<br>
In full width layout mode the page background is covered by the header, slider, body and footer backgrounds respectively. If the color opacity of these areas is 1 or an opaque image is used, the page background won\'t be visible.<br>
If you want to use an image as a background, enabling the cover button will resize and crop the image so that it will always fit the browser window on any resolution.<br>
You can override this option on a page by page basis.', 'vip-restaurant') ),
	'id'   => 'background',
	'type' => 'background',
	'show' => 'color,image,repeat,size,attachment',
),

array(
	'name' => esc_html__( 'Body Background', 'vip-restaurant' ),
	'desc' => esc_html__( 'If you want to use an image as a background, enabling the cover button will resize and crop the image so that it will always fit the browser window on any resolution. If the color opacity  is less than 1 the page background underneath will be visible.', 'vip-restaurant' ),
	'id'   => 'local-main-background',
	'type' => 'background',
	'show' => 'color,image,repeat,size,attachment',
),

array(
	'name'    => esc_html__( 'Page Vertical Padding', 'vip-restaurant' ),
	'id'      => 'page-vertical-padding',
	'type'    => 'select',
	'default' => 'both',
	'options' => array(
		'both'        => esc_html__( 'Both top and bottom padding', 'vip-restaurant' ),
		'top-only'    => esc_html__( 'Only top padding', 'vip-restaurant' ),
		'bottom-only' => esc_html__( 'Only bottom padding', 'vip-restaurant' ),
		'none'        => esc_html__( 'No vertical padding', 'vip-restaurant' ),
	),
),

);
