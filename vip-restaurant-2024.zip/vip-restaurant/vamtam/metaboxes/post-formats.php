<?php
/**
 * Vamtam Post Format Options
 *
 * @package vip-restaurant
 */

return array(

array(
	'name' => esc_html__( 'Standard', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-0',
),

array(
	'name' => esc_html__( 'How do I use standard post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Just use the editor below.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

// --

array(
	'name' => esc_html__( 'Aside', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-aside',
),

array(
	'name' => esc_html__( 'How do I use aside post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Just use the editor below. The post title will not be shown publicly.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

// --

array(
	'name' => esc_html__( 'Link', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-link',
),

array(
	'name' => esc_html__( 'How do I use link post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Use the editor below for the post body, put the link in the option below.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

array(
	'name' => esc_html__( 'Link', 'vip-restaurant' ),
	'id' => 'vamtam-post-format-link',
	'type' => 'text',
),

// --

array(
	'name' => esc_html__( 'Image', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-image',
),

array(
	'name' => esc_html__( 'How do I use image post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Use the standard Featured Image option.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

// --

array(
	'name' => esc_html__( 'Video', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-video',
),

array(
	'name' => esc_html__( 'How do I use video post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Put the url of the video below. You must use an oEmbed provider supported by WordPress or a file supported by the [video] shortcode which comes with WordPress.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

array(
	'name' => esc_html__( 'Link', 'vip-restaurant' ),
	'id' => 'vamtam-post-format-video-link',
	'type' => 'text',
),

// --

array(
	'name' => esc_html__( 'Audio', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-audio',
),

array(
	'name' => esc_html__( 'How do I use auido post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Put the url of the audio below. You must use an oEmbed provider supported by WordPress or a file supported by the [audio] shortcode which comes with WordPress.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

array(
	'name' => esc_html__( 'Link', 'vip-restaurant' ),
	'id' => 'vamtam-post-format-audio-link',
	'type' => 'text',
),

// --

array(
	'name' => esc_html__( 'Quote', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-quote',
),

array(
	'name' => esc_html__( 'How do I use quote post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Simply fill in author and link fields', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

array(
	'name' => esc_html__( 'Author', 'vip-restaurant' ),
	'id' => 'vamtam-post-format-quote-author',
	'type' => 'text',
),

array(
	'name' => esc_html__( 'Link', 'vip-restaurant' ),
	'id' => 'vamtam-post-format-quote-link',
	'type' => 'text',
),

// --

array(
	'name' => esc_html__( 'Gallery', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-gallery',
),

array(
	'name' => esc_html__( 'How do I use gallery post format?', 'vip-restaurant' ),
	'desc' => esc_html__( 'Use the "Add Media" in a text/image block element to create a gallery.This button is also found in the top left side of the visual and text editors.', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

// --

array(
	'name' => esc_html__( 'Status', 'vip-restaurant' ),
	'type' => 'separator',
	'tab_class' => 'vamtam-post-format-status',
),

array(
	'name' => esc_html__( 'How do I use this post format?', 'vip-restaurant' ),
	'desc' => esc_html__( '...', 'vip-restaurant' ),
	'type' => 'info',
	'visible' => true,
),

);
