<?php
/**
 * Vamtam Post Options
 *
 * @package vip-restaurant
 */

return array(

array(
	'name' => esc_html__( 'General', 'vip-restaurant' ),
	'type' => 'separator',
),

array(
	'name'    => esc_html__( 'Cite', 'vip-restaurant' ),
	'id'      => 'testimonial-author',
	'default' => '',
	'type'    => 'text',
) ,

array(
	'name'    => esc_html__( 'Link', 'vip-restaurant' ),
	'id'      => 'testimonial-link',
	'default' => '',
	'type'    => 'text',
) ,

array(
	'name'    => esc_html__( 'Rating', 'vip-restaurant' ),
	'id'      => 'testimonial-rating',
	'default' => 5,
	'type'    => 'range',
	'min'     => 0,
	'max'     => 5,
) ,

array(
	'name'    => esc_html__( 'Summary', 'vip-restaurant' ),
	'id'      => 'testimonial-summary',
	'default' => '',
	'type'    => 'text',
) ,

);
