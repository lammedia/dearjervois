<?php
return array(
	'name'    => esc_html__( 'Vertical Blank Space', 'vip-restaurant' ),
	'value'   => 'push',
	'options' => array(
		array(
			'name'    => esc_html__( 'Height', 'vip-restaurant' ),
			'id'      => 'h',
			'default' => 30,
			'min'     => -200,
			'max'     => 200,
			'type'    => 'range',
		) ,
		array(
			'name'    => esc_html__( 'Hide on Low Resolutions', 'vip-restaurant' ),
			'id'      => 'hide_low_res',
			'default' => false,
			'type'    => 'toggle',
		) ,
		array(
			'name'    => esc_html__( 'Class', 'vip-restaurant' ),
			'id'      => 'class',
			'default' => '',
			'type'    => 'text',
		) ,
	),
);
