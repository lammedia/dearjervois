<?php
return array(
	'name'    => esc_html__( 'Drop Cap', 'vip-restaurant' ),
	'value'   => 'dropcap',
	'options' => array(
		array(
			'name'    => esc_html__( 'Type', 'vip-restaurant' ),
			'id'      => 'type',
			'default' => '1',
			'type'    => 'select',
			'options' => array(
				'1' => esc_html__( 'Type 1', 'vip-restaurant' ),
				'2' => esc_html__( 'Type 2', 'vip-restaurant' ),
			),
		) ,
		array(
			'name'    => esc_html__( 'Letter', 'vip-restaurant' ),
			'id'      => 'letter',
			'default' => '',
			'type'    => 'text',
		) ,
		array(
			'name'    => esc_html__( 'Text', 'vip-restaurant' ),
			'id'      => 'text',
			'default' => '',
			'type'    => 'text',
		) ,
	),
);
