<?php

return array(
	'name'    => esc_html__( 'Styled List', 'vip-restaurant' ),
	'value'   => 'list',
	'options' => array(
		array(
			'name'    => esc_html__( 'Style', 'vip-restaurant' ),
			'id'      => 'style',
			'default' => '',
			'type'    => 'icons',
		) ,
		array(
			'name'    => esc_html__( 'Color', 'vip-restaurant' ),
			'id'      => 'color',
			'default' => '',
			'options' => array(
				'accent1' => esc_html__( 'Accent 1', 'vip-restaurant' ),
				'accent2' => esc_html__( 'Accent 2', 'vip-restaurant' ),
				'accent3' => esc_html__( 'Accent 3', 'vip-restaurant' ),
				'accent4' => esc_html__( 'Accent 4', 'vip-restaurant' ),
				'accent5' => esc_html__( 'Accent 5', 'vip-restaurant' ),
				'accent6' => esc_html__( 'Accent 6', 'vip-restaurant' ),
				'accent7' => esc_html__( 'Accent 7', 'vip-restaurant' ),
				'accent8' => esc_html__( 'Accent 8', 'vip-restaurant' ),
			),
			'type' => 'select',
		) ,
		array(
			'name'    => esc_html__( 'Content', 'vip-restaurant' ),
			'desc'    => esc_html__( 'Please insert a valid HTML unordered list', 'vip-restaurant' ),
			'id'      => 'content',
			'type'    => 'textarea',
			'default' => wp_kses_post( __( '<ul>
                <li>list item</li>
                <li>another item</li>
            </ul>', 'vip-restaurant' ) ),
		) ,
	),
);
