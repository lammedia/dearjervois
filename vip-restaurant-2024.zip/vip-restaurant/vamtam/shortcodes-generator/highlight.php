<?php

return array(
	'name'    => esc_html__( 'Highlight', 'vip-restaurant' ),
	'value'   => 'highlight',
	'options' => array(
		array(
			'name'    => esc_html__( 'Type', 'vip-restaurant' ),
			'id'      => 'type',
			'default' => '',
			'type'    => 'select',
			'options' => array(
				'light' => esc_html__( 'light', 'vip-restaurant' ),
				'dark'  => esc_html__( 'dark', 'vip-restaurant' ),
			),
		) ,
		array(
			'name'    => esc_html__( 'Content', 'vip-restaurant' ),
			'id'      => 'content',
			'default' => '',
			'type'    => 'textarea',
		) ,
	),
);
