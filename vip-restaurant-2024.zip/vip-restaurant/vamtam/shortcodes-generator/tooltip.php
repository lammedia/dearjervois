<?php
return 	array(
	'name'    => 'Tooltip',
	'value'   => 'tooltip',
	'options' => array(
		array(
			'name'    => esc_html__( 'Tooltip content', 'vip-restaurant' ),
			'id'      => 'tooltip_content',
			'default' => '',
			'type'    => 'textarea',
		),
		array(
			'name'    => esc_html__( 'Tooltip trigger', 'vip-restaurant' ),
			'id'      => 'content',
			'default' => '',
			'type'    => 'textarea',
		),
	),
);
