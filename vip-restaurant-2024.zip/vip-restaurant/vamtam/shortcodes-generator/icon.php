<?php

return array(
	'name'    => esc_html__( 'Icon', 'vip-restaurant' ),
	'value'   => 'icon',
	'options' => array(
		array(
			'name'    => esc_html__( 'Name', 'vip-restaurant' ),
			'id'      => 'name',
			'default' => '',
			'type'    => 'icons',
		) ,
		array(
			'name'    => esc_html__( 'Color (optional)', 'vip-restaurant' ),
			'id'      => 'color',
			'default' => '',
			'prompt'  => '',
			'type'    => 'select',
			'options' => array(
				'accent1' => esc_html__( 'Accent 1', 'vip-restaurant' ),
				'accent2' => esc_html__( 'Accent 2', 'vip-restaurant' ),
				'accent3' => esc_html__( 'Accent 3', 'vip-restaurant' ),
				'accent4' => esc_html__( 'Accent 4', 'vip-restaurant' ),
				'accent5' => esc_html__( 'Accent 5', 'vip-restaurant' ),
				'accent6' => esc_html__( 'Accent 6', 'vip-restaurant' ),
				'accent7' => esc_html__( 'Accent 7', 'vip-restaurant' ),
				'accent8' => esc_html__( 'Accent 8', 'vip-restaurant' ),
			),
		) ,
		array(
			'name'    => esc_html__( 'Size', 'vip-restaurant' ),
			'id'      => 'size',
			'type'    => 'range',
			'default' => 16,
			'min'     => 8,
			'max'     => 100,
		),
		array(
			'name'    => esc_html__( 'Style', 'vip-restaurant' ),
			'id'      => 'style',
			'default' => '',
			'prompt'  => esc_html__( 'Default', 'vip-restaurant' ),
			'type' => 'select',
			'options' => array(
				'border' => esc_html__( 'Border', 'vip-restaurant' ),
			),
		) ,
	),
);
