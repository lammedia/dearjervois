<?php

return array(
	array(
		'label'     => esc_html__( 'Layout', 'vip-restaurant' ),
		'id'        => 'top-bar-layout',
		'type'      => 'select',
		'transport' => 'postMessage',
		'choices'   => array(
			''            => esc_html__( 'Disabled', 'vip-restaurant' ),
			'menu-social' => esc_html__( 'Left: Menu, Right: Social Icons', 'vip-restaurant' ),
			'social-menu' => esc_html__( 'Left: Social Icons, Right: Menu', 'vip-restaurant' ),
			'text-menu'   => esc_html__( 'Left: Text, Right: Menu', 'vip-restaurant' ),
			'menu-text'   => esc_html__( 'Left: Menu, Right: Text', 'vip-restaurant' ),
			'social-text' => esc_html__( 'Left: Social Icons, Right: Text', 'vip-restaurant' ),
			'text-social' => esc_html__( 'Left: Text, Right: Social Icons', 'vip-restaurant' ),
			'fulltext'    => esc_html__( 'Text only', 'vip-restaurant' ),
		),
	),

	array(
		'label'       => esc_html__( 'Text', 'vip-restaurant' ),
		'description' => esc_html__( 'You can place plain text, HTML and shortcodes.', 'vip-restaurant' ),
		'id'          => 'top-bar-text',
		'type'        => 'textarea',
		'transport'   => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Social Text Lead', 'vip-restaurant' ),
		'id'        => 'top-bar-social-lead',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Facebook Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-fb',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Twitter Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-twitter',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'LinkedIn Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-linkedin',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Google+ Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-gplus',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Flickr Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-flickr',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Pinterest Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-pinterest',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Dribbble Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-dribbble',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Instagram Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-instagram',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'YouTube Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-youtube',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Vimeo Link', 'vip-restaurant' ),
		'id'        => 'top-bar-social-vimeo',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'       => esc_html__( 'Background', 'vip-restaurant' ),
		'description' => wp_kses_post( __( 'If you want to use an image as a background, enabling the cover button will resize and crop the image so that it will always fit the browser window on any resolution.<br> If the color opacity is less than 1 the page background underneath will be visible.', 'vip-restaurant' ) ),
		'id'          => 'top-nav-background',
		'type'        => 'background',
		'transport'   => 'postMessage',
		'skin'        => true,
		'show'        => array(
			'background-attachment' => false,
			'background-position'   => false,
		),
	),

	array(
		'label'   => esc_html__( 'Colors', 'vip-restaurant' ),
		'type'    => 'color-row',
		'id'      => 'css-tophead',
		'choices' => array(
			'text-color'       => esc_html__( 'Text Color:', 'vip-restaurant' ),
			'link-color'       => esc_html__( 'Link Color:', 'vip-restaurant' ),
			'link-hover-color' => esc_html__( 'Link Hover Color:', 'vip-restaurant' ),
		),
		'compiler'  => true,
		'transport' => 'postMessage',
		'skin'      => true,
	),

	array(
		'label'   => esc_html__( 'Sub-Menus', 'vip-restaurant' ),
		'type'    => 'color-row',
		'id'      => 'submenu',
		'choices' => array(
			'background'  => esc_html__( 'Background:', 'vip-restaurant' ),
			'color'       => esc_html__( 'Text Normal Color:', 'vip-restaurant' ),
			'hover-color' => esc_html__( 'Text Hover Color:', 'vip-restaurant' ),
		),
		'compiler'  => true,
		'transport' => 'postMessage',
		'skin'      => true,
	),
);