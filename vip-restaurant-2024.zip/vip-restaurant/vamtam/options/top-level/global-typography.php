<?php
/**
 * Theme options / Styles / General Typography
 *
 * @package vip-restaurant
 */

return array(

array(
	'label'  => esc_html__( 'Headlines', 'vip-restaurant' ),
	'type'   => 'heading',
	'id'     => 'styles-typography-headlines',
),

array(
	'label'      => esc_html__( 'H1', 'vip-restaurant' ),
	'id'         => 'h1',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'H2', 'vip-restaurant' ),
	'id'         => 'h2',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'H3', 'vip-restaurant' ),
	'id'         => 'h3',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'H4', 'vip-restaurant' ),
	'id'         => 'h4',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'H5', 'vip-restaurant' ),
	'id'         => 'h5',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'H6', 'vip-restaurant' ),
	'id'         => 'h6',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'  => esc_html__( 'Additional Fonts', 'vip-restaurant' ),
	'type'   => 'heading',
	'id'     => 'styles-typography-additional',
),

array(
	'label'      => esc_html__( 'Emphasis Font', 'vip-restaurant' ),
	'id'         => 'em',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'Style 1', 'vip-restaurant' ),
	'id'         => 'additional-font-1',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'      => esc_html__( 'Style 2', 'vip-restaurant' ),
	'id'         => 'additional-font-2',
	'type'       => 'typography',
	'compiler'   => true,
	'transport'  => 'postMessage',
	'skin'       => true,
),

array(
	'label'  => esc_html__( 'Google Fonts Options', 'vip-restaurant' ),
	'type'   => 'heading',
	'id'     => 'styles-typography-gfonts',
),

array(
	'label'      => esc_html__( 'Style 2', 'vip-restaurant' ),
	'id'         => 'gfont-subsets',
	'type'       => 'multicheck',
	'transport'  => 'postMessage',
	'choices'    => vamtam_get_google_fonts_subsets(),
	'skin'       => true,
),

);
