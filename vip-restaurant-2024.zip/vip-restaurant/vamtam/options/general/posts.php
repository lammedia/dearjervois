<?php

/**
 * Theme options / General / Posts
 *
 * @package vip-restaurant
 */

return array(

	array(
		'label'       => esc_html__( 'Pagination Type', 'vip-restaurant' ),
		'description' => esc_html__( 'Also used for portfolio', 'vip-restaurant' ),
		'id'          => 'pagination-type',
		'type'        => 'select',
		'choices'     => array(
			'paged'              => esc_html__( 'Paged', 'vip-restaurant' ),
			'load-more'          => esc_html__( 'Load more button', 'vip-restaurant' ),
			'infinite-scrolling' => esc_html__( 'Infinite scrolling', 'vip-restaurant' ),
		),
	),

	array(
		'label'       => esc_html__( 'Show "Related Posts" in Single Post View', 'vip-restaurant' ),
		'description' => esc_html__( 'Enabling this option will show more posts from the same category when viewing a single post.', 'vip-restaurant' ),
		'id'          => 'show-related-posts',
		'type'        => 'switch',
		'transport'   => 'postMessage',
	),

	array(
		'label'     => esc_html__( '"Related Posts" title', 'vip-restaurant' ),
		'id'        => 'related-posts-title',
		'type'      => 'text',
		'transport' => 'postMessage',
	),

	array(
		'label'     => esc_html__( 'Meta Information', 'vip-restaurant' ),
		'id'        => 'post-meta',
		'type'      => 'multicheck',
		'transport' => 'postMessage',
		'choices'   => array(
			'author'   => esc_html__( 'Post Author', 'vip-restaurant' ),
			'tax'      => esc_html__( 'Categories and Tags', 'vip-restaurant' ),
			'date'     => esc_html__( 'Timestamp', 'vip-restaurant' ),
			'comments' => esc_html__( 'Comment Count', 'vip-restaurant' ),
		),
	),

	array(
		'label'       => esc_html__( 'Show Featured Image on Single Posts', 'vip-restaurant' ),
		'id'          => 'show-single-post-image',
		'description' => esc_html__( 'Please note, that this option works only for Blog Post Format Image.', 'vip-restaurant' ),
		'type'        => 'switch',
		'transport'   => 'postMessage',
	),

	array(
		'label'       => esc_html__( 'Post Archive Layout', 'vip-restaurant' ),
		'description' => '',
		'id'          => 'archive-layout',
		'type'        => 'radio',
		'choices'     => array(
			'normal' => esc_html__( 'Large', 'vip-restaurant' ),
			'mosaic' => esc_html__( 'Small', 'vip-restaurant' ),
		),
	),

);
