<?php

/**
 * Declare plugin dependencies
 *
 * @package vip-restaurant
 */

/**
 * Declare plugin dependencies
 */
function vamtam_register_required_plugins() {
	$plugins = array(
		array(
			'name' => esc_html__( 'Classic Editor', 'vip-restaurant' ),
			'slug' => 'classic-editor',
			'required' => true,
		),

		[
			'name'     => esc_html__( 'Classic Widgets', 'vip-restaurant' ),
			'slug'     => 'classic-widgets',
			'required' => true,
			'category' => 'required',
		],

		array(
			'name'     => esc_html__( 'Jetpack', 'vip-restaurant' ),
			'slug'     => 'jetpack',
			'required' => true,
		),

		array(
			'name'     => esc_html__( 'Vamtam Offline Jetpack', 'vip-restaurant' ),
			'slug'     => 'vamtam-offline-jetpack',
			'source'   => VAMTAM_PLUGINS . 'vamtam-offline-jetpack.zip',
			'required' => true,
			'category' => 'required',
			'version'  => '1.0.0',
		),

		array(
			'name'     => esc_html__( 'WP Retina 2x', 'vip-restaurant' ),
			'slug'     => 'wp-retina-2x',
			'required' => false,
		),

		array(
			'name'     => esc_html__( 'WooCommerce', 'vip-restaurant' ),
			'slug'     => 'woocommerce',
			'required' => true,
		),

		array(
			'name'     => esc_html__( 'WooCommerce Product Archive Customiser', 'vip-restaurant' ),
			'slug'     => 'woocommerce-product-archive-customiser',
			'required' => false,
		),

		array(
			'name'     => esc_html__( 'Max Mega Menu', 'vip-restaurant' ),
			'slug'     => 'megamenu',
			'required' => true,
		),

		array(
			'name'     => esc_html__( 'Instagram Feed', 'vip-restaurant' ),
			'slug'     => 'instagram-feed',
			'required' => false,
		),

		array(
			'name'     => esc_html__( 'Ninja Forms', 'vip-restaurant' ),
			'slug'     => 'ninja-forms',
			'required' => true,
		),

		array(
			'name'     => esc_html__( 'Google Maps Easy', 'vip-restaurant' ),
			'slug'     => 'google-maps-easy',
			'required' => true,
		),

		array(
			'name'     => esc_html__( 'MailChimp for WordPress', 'vip-restaurant' ),
			'slug'     => 'mailchimp-for-wp',
			'required' => false,
		),

		array(
			'name'     => esc_html__( 'Under Construction / Maintenance Mode from Acurax', 'vip-restaurant' ),
			'slug'     => 'coming-soon-maintenance-mode-from-acurax',
			'required' => false,
		),

		array(
			'name'     => esc_html__( 'Vamtam Elements (A)', 'vip-restaurant' ),
			'slug'     => 'vamtam-elements-a',
			'source'   => VAMTAM_PLUGINS . 'vamtam-elements-a.zip',
			'required' => true,
			'version'  => '1.0.1',
		),

		array(
			'name'     => esc_html__( 'Vamtam Twitter', 'vip-restaurant' ),
			'slug'     => 'vamtam-twitter',
			'source'   => VAMTAM_PLUGINS . 'vamtam-twitter.zip',
			'required' => true,
			'version'  => '1.0.3',
		),

		array(
			'name'     => esc_html__( 'Vamtam Importers', 'vip-restaurant' ),
			'slug'     => 'vamtam-importers',
			'source'   => VAMTAM_PLUGINS . 'vamtam-importers.zip',
			'required' => true,
			'version'  => '1',
		),

		array(
			'name'     => esc_html__( 'Revolution Slider', 'vip-restaurant' ),
			'slug'     => 'revslider',
			'source'   => VAMTAM_PLUGINS . 'revslider.zip',
			'required' => true,
			'version'  => '5.1.6',
		),

		array(
			'name'     => esc_html__( 'foodpress', 'vip-restaurant' ),
			'slug'     => 'foodpress',
			'source'   => VAMTAM_PLUGINS . 'foodpress.zip',
			'required' => true,
			'version'  => '1.4.2',
		),
	);

	$config = array(
		'default_path' => '',    // Default absolute path to pre-packaged plugins
		'is_automatic' => true,  // Automatically activate plugins after installation or not
	);

	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'vamtam_register_required_plugins' );

function vamtam_tgmpa_bulk_install_setup() {
	if ( isset( $_GET['page'] ) && $_GET['page'] === 'tgmpa-install-plugins' ) {
		// this disables the fastcgi buffering for nginx servers
		header('X-Accel-Buffering: no');
	}
}
add_action('admin_init', 'vamtam_tgmpa_bulk_install_setup');
