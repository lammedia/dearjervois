<?php
/**
 * Content wrappers
 *
 * @author  VamTam
 * @package vip-restaurant
 * @version 3.3.0
 */

global $post;

?>
		</div>
	</article>
	<?php get_template_part( 'sidebar' ) ?>
</div>
